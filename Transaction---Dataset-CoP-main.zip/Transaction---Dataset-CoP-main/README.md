# Consistency over Permutations (CoP) for Label Reliability in Function-Level Vulnerability Datasets

A research repository for auditing label reliability in function-level software vulnerability datasets using calibrated CodePTMs and permutation-based agreement analysis.


# Consistency over Permutations (CoP)

![Figure](https://drive.google.com/uc?export=view&id=17NGKGIbpiB8G3u3cE8ep7VYY5e8--Vfl)

## Overview

This repository contains the implementation and experimental workflow for **Consistency over Permutations (CoP)**, a permutation-based annotation and label-auditing framework for vulnerability datasets.

Instead of depending on a single model, CoP combines calibrated probabilities from multiple pretrained code models and evaluates agreement across all model subsets. This helps identify stable labels, disagreement-heavy samples, and suspicious instances that may require further review.

The framework is designed to support:

- label reliability analysis
- disagreement-aware sample triage
- majority-vote auditing across model permutations
- calibration-aware annotation using CodePTMs
- dataset-level comparison across multiple vulnerability benchmarks

---

## Motivation

Building high-quality vulnerability datasets is expensive and time-consuming because annotation often requires expert review. CoP is designed as a scalable alternative that uses calibrated model agreement to check how reliable dataset labels are before using them in downstream vulnerability detection tasks.

---

## Proposed Method: CoP

For each sample, CoP performs the following steps:

1. obtains calibrated probabilities from multiple CodePTMs  
2. generates all model-subset permutations  
3. applies majority voting within each subset  
4. measures agreement consistency  
5. flags unstable or disagreement-prone samples for further inspection  

This makes CoP useful as a lightweight and scalable dataset auditing framework.

---
## CoP Workflow Figure

![CoP Workflow](https://drive.google.com/uc?export=view&id=15TP7r_GAYgsddL42LOzbJfbwK0ZBUUI3)

This figure presents the overall CoP-based dataset auditing pipeline, including preprocessing, multi-model training, calibration, permutation consistency analysis, and suspect-sample triage.
## Datasets

The experiments are conducted on four C/C++ vulnerability datasets:

- **MegaVul**
- **CVEFixes**
- **Devign**
- **Big-Vul**

---

## Models

The repository uses the following pretrained code models:

- **CodeBERT**
- **GraphCodeBERT**
- **UniXcoder**
- **Qwen2.5-Coder-1.5B**

---

## Main Results

### Best overall dataset
- **Big-Vul** achieved the strongest overall result in this study.
- Best single-model result: **80.00% Accuracy** and **80.45% F1**
- Best CoP combination result: **78.70% Accuracy** and **80.55% F1**

### MegaVul
- Strong ensemble consistency was observed.
- The full 4-model CoP setup achieved **78.24% F1**
- Unanimous agreement coverage was high, indicating relatively stable labels

### CVEFixes
- More disagreement-heavy than MegaVul
- Best single-model result came from **QwenCoder**
- **66.08% Accuracy** and **64.62% F1**

### Devign
- More difficult and disagreement-prone than MegaVul and Big-Vul
- Best single-model result came from **CodeBERT**
- **66.83% Accuracy** and **61.06% F1**

---


## Table III. Majority-vote CoP Metrics Across All Model Combinations for MegaVul

**Abbreviations:** U = UniXcoder, G = GraphCodeBERT, C = CodeBERT, Q = QwenCoder

| Models | k | Acc | Prec. | Recall | Spec. | F1 | MCC | Kappa | AUC | PR-AUC | Brier | LogLoss |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| UniXcoder (U) | 1 | 77.12 | 76.54 | 78.22 | 76.02 | 77.37 | 0.543 | 0.542 | 0.7712 | 0.7076 | 0.2288 | 6.3217 |
| GraphCodeBERT (G) | 1 | 75.59 | 75.54 | 75.69 | 75.49 | 75.61 | 0.512 | 0.512 | 0.7559 | 0.6933 | 0.2441 | 6.7444 |
| CodeBERT (C) | 1 | 74.98 | 78.71 | 68.48 | 81.47 | 73.24 | 0.504 | 0.500 | 0.7498 | 0.6966 | 0.2502 | 6.9135 |
| QwenCoder (Q) | 1 | 73.84 | 75.07 | 71.38 | 76.30 | 73.18 | 0.477 | 0.477 | 0.7384 | 0.6790 | 0.2616 | 7.2286 |
| C+U | 2 | 76.51 | 73.36 | 83.25 | 69.76 | 77.99 | 0.535 | 0.530 | 0.8100 | 0.7607 | 0.1923 | 4.1391 |
| U+G | 2 | 76.02 | 71.91 | 85.40 | 66.65 | 78.08 | 0.530 | 0.520 | 0.8099 | 0.7556 | 0.1926 | 4.2298 |
| C+G | 2 | 75.72 | 73.46 | 80.53 | 70.90 | 76.83 | 0.517 | 0.514 | 0.7936 | 0.7435 | 0.2071 | 4.7265 |
| U+Q | 2 | 75.72 | 71.16 | 86.48 | 64.95 | 78.08 | 0.527 | 0.514 | 0.8132 | 0.7598 | 0.1880 | 3.7711 |
| C+Q | 2 | 75.69 | 72.58 | 82.56 | 68.82 | 77.25 | 0.519 | 0.514 | 0.8006 | 0.7510 | 0.1992 | 4.0925 |
| Q+G | 2 | 75.26 | 70.83 | 85.90 | 64.62 | 77.64 | 0.517 | 0.505 | 0.8057 | 0.7513 | 0.1937 | 3.8839 |
| C+U+Q | 3 | 77.79 | 79.33 | 75.16 | 80.42 | 77.19 | 0.557 | 0.556 | 0.8309 | 0.7882 | 0.1752 | 2.9260 |
| U+Q+G | 3 | 77.65 | 77.69 | 77.58 | 77.72 | 77.63 | 0.553 | 0.553 | 0.8331 | 0.7880 | 0.1736 | 2.8513 |
| C+U+G | 3 | 77.09 | 77.99 | 75.49 | 78.69 | 76.72 | 0.542 | 0.542 | 0.8241 | 0.7813 | 0.1827 | 3.3860 |
| C+Q+G | 3 | 76.62 | 78.31 | 73.63 | 79.61 | 75.90 | 0.533 | 0.532 | 0.8226 | 0.7791 | 0.1827 | 3.1209 |
| C+U+Q+G | 4 | 77.48 | 75.69 | 80.97 | 73.99 | 78.24 | 0.551 | 0.550 | 0.8401 | 0.8032 | 0.1701 | 2.4663 |



## Table XIX. Comparison of Different Flagging Methods Across Devign, CVEFixes, Big-Vul, and MegaVul Datasets

| Dataset | Method | Flagged | Flag Rate (%) | Maj4 Mismatch (%) | Uncertain (%) |
|---|---|---:|---:|---:|---:|
| Devign | OURS (disputed/tie + strong_ens) | 2121 | 75.56 | 21.59 | 60.68 |
| Devign | CLEANLAB(topK) | 959 | 34.16 | 42.86 | 35.56 |
| Devign | SingleConf(CodeBERT strong) | 64 | 2.28 | 60.94 | 34.38 |
| CVEFixes | OURS (disputed/tie + strong_ens) | 339 | 100.00 | 17.99 | 45.43 |
| CVEFixes | CLEANLAB(topK) | 115 | 33.92 | 53.04 | 46.96 |
| CVEFixes | SingleConf(CodeBERT strong) | 0 | 0.00 | 0.00 | 0.00 |
| Big-Vul | OURS (disputed/tie + strong_ens) | 1113 | 55.65 | 14.91 | 72.78 |
| Big-Vul | CLEANLAB(topK) | 279 | 13.95 | 53.41 | 40.50 |
| Big-Vul | SingleConf(CodeBERT strong) | 123 | 6.15 | 41.46 | 43.09 |
| MegaVul | OURS (disputed/tie + strong_ens) | 3014 | 41.92 | 34.07 | 25.35 |
| MegaVul | CLEANLAB(topK) | 1000 | 13.91 | 99.60 | 0.40 |
| MegaVul | SingleConf(CodeBERT strong) | 706 | 9.82 | 76.06 | 17.00 |





## Installation
git clone https://github.com/your-username/cop-label-reliability.git
cd cop-label-reliability
pip install -r requirements.txt

## Load Models

bash scripts/train_all.sh

## calibration
bash scripts/calibrate_all.sh
## Run CoP
bash scripts/run_cop.sh

## Citation
@article{karim2026cop,
  title={Consistency over Permutations (CoP) to Measure Label Reliability in Function-Level Vulnerability Dataset},
  author={Karim, Tasmin and Akter, Mst. Shapna},
  journal={IEEE Transactions on Reliability},
  note={Manuscript under review},
  year={2026}
}

## Repository Structure

```text
cop-label-reliability/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
│
├── data/
│   ├── raw/
│   │   ├── megavul/
│   │   ├── cvefixes/
│   │   ├── devign/
│   │   └── bigvul/
│   ├── processed/
│   └── splits/
│
├── configs/
│   ├── training/
│   ├── calibration/
│   └── evaluation/
│
├── src/
│   ├── data/
│   │   ├── load_data.py
│   │   ├── preprocess.py
│   │   └── split_data.py
│   ├── models/
│   │   ├── codebert.py
│   │   ├── graphcodebert.py
│   │   ├── unixcoder.py
│   │   └── qwencoder.py
│   ├── calibration/
│   │   ├── temperature_scaling.py
│   │   └── calibrate_probs.py
│   ├── cop/
│   │   ├── permutations.py
│   │   ├── voting.py
│   │   ├── agreement.py
│   │   └── triage.py
│   ├── evaluation/
│   │   ├── metrics.py
│   │   ├── error_analysis.py
│   │   └── compare_cleanlab.py
│   └── utils/
│       ├── seed.py
│       ├── logger.py
│       └── io.py
│
├── notebooks/
│   ├── 01_data_preparation.ipynb
│   ├── 02_model_training.ipynb
│   ├── 03_calibration.ipynb
│   ├── 04_cop_analysis.ipynb
│   ├── 05_error_analysis.ipynb
│   └── 06_plots_tables.ipynb
│
├── results/
│   ├── tables/
│   ├── figures/
│   ├── logs/
│   └── predictions/
│
├── scripts/
│   ├── train_all.sh
│   ├── calibrate_all.sh
│   ├── run_cop.sh
│   └── evaluate_all.sh
│
└── paper/
    ├── manuscript.pdf
    ├── supplementary.pdf
    └── figures/
